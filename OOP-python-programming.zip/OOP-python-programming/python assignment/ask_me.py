print("I am very glad to help you.")
NAME=str(input("May You please enter your name!! "))
print("Hello",NAME,"How may I  help you?")